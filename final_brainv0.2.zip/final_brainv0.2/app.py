from flask import Flask, request, render_template, redirect, url_for
import numpy as np
import scipy.io
import tensorflow as tf
import pandas as pd
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load the model
def load_model():
    model_path = 'model/brain.h5'
    
    def expand_dims_layer(x):
        return tf.expand_dims(x, axis=2)
    
    def custom_output_shape(input_shape):
        return (input_shape[0], input_shape[1], 1)
    
    try:
        model = tf.keras.models.load_model(
            model_path,
            custom_objects={
                'Lambda': tf.keras.layers.Lambda(expand_dims_layer, output_shape=custom_output_shape)
            },
            compile=False
        )
        print("Model loaded successfully!")
        return model
    except Exception as e:
        print(f"Error loading model: {e}")
        return None

model = load_model()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        input_data = request.form.get('input_data')
        input_data = list(map(float, input_data.split(',')))
        input_data = np.array(input_data).reshape(1, 8)
        prediction = model.predict(input_data)
        return render_template('index.html', prediction=prediction[0][0])
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file part'
        file = request.files['file']
        if file.filename == '':
            return 'No selected file'
        if file and file.filename.endswith('.csv'):
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filepath)
            return redirect(url_for('display_text', filename=file.filename))
    return render_template('upload.html')

@app.route('/display/<filename>')
def display_text(filename):
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    df = pd.read_csv(filepath)
    extracted_text = df.to_html()
    return render_template('display.html', extracted_text=extracted_text)

if __name__ == '__main__':
    app.run(debug=True)
